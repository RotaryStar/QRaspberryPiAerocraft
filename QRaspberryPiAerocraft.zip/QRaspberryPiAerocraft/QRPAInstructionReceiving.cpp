#include "QRPAInstructionReceiving.h"

QRPAInstructionReceiving::QRPAInstructionReceiving(QRPAMotorController *QRPAC, QObject *parent) : QObject(parent)
{
	socket = NULL;
	mQRPAC = QRPAC;

	if (server.listen(QHostAddress::Any, 25678))
	{
		qDebug() << "listen successful , port : 25678";
		connect(&server, &QTcpServer::newConnection, this, &QRPAInstructionReceiving::hasNewConnection);
	}
    else
    {
        qDebug() << "listen falid , port : 25678";
    }
}

void QRPAInstructionReceiving::hasNewConnection()
{
    if (!socket)
	{
		socket = server.nextPendingConnection();

		connect(socket, &QTcpSocket::readyRead, this, &QRPAInstructionReceiving::readyReadFromController);
        connect(socket, &QTcpSocket::disconnected, this, &QRPAInstructionReceiving::disconnectFromC);

        mQRPAC->setPwmCreate(10);
        qDebug() << "has new Connection , connected !";
	}
	else
	{
		qDebug() << "has new Connection , rejected ! because: has a connection connected ";
	}
}

void QRPAInstructionReceiving::disconnectFromC()

{
    delete socket;
    socket = NULL;
    qDebug() << "disconnected ! ";
}

void QRPAInstructionReceiving::readyReadFromController()
{
	QByteArray data = socket->readAll();

    float power = data.toFloat();
    power = (float)power*(float)(mQRPAC->maxPower - mQRPAC->minPower) + mQRPAC->minPower;
    qDebug() << power;

	if (power > mQRPAC->maxPower)
	{
		power = mQRPAC->maxPower -((mQRPAC->maxPower - mQRPAC->minPower)/2);
	}
	else if (power < mQRPAC->minPower)
	{
		power = mQRPAC->minPower + ((mQRPAC->maxPower - mQRPAC->minPower) / 2);
	}

    int powerValue = (int)power;

    qDebug() << powerValue;

    mQRPAC->setPwmCreate(powerValue);
}
