#include "QRPAInstructionReceiving.h"

QRPAInstructionReceiving::QRPAInstructionReceiving(QObject *parent) : QObject(parent)
{

}
