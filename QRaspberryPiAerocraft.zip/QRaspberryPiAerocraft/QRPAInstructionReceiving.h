#ifndef QRPAINSTRUCTIONRECEIVING_H
#define QRPAINSTRUCTIONRECEIVING_H

#include <QObject>
#include <qtcpsocket.h>
#include <qtcpserver.h>

#include "QRPAMotorController.h"

class QRPAInstructionReceiving : public QObject
{
    Q_OBJECT
public:
	explicit QRPAInstructionReceiving(QRPAMotorController *QRPAC, QObject *parent = 0);

signals:

private:
	QTcpServer server;
	QTcpSocket *socket;
	QRPAMotorController *mQRPAC;
private:
	void hasNewConnection();
    void disconnectFromC();

	void readyReadFromController();

public slots:
};

#endif // QRPAINSTRUCTIONRECEIVING_H
