#include "QRPAManager.h"

QRPAManager::QRPAManager(QObject *parent) : QObject(parent)
{

	qDebug() << QString::fromLocal8Bit("start loading . . . .");
	QRPAMc = new QRPAMotorController(this);

	QRPAIr = new QRPAInstructionReceiving(QRPAMc,this);

	qDebug() << QString::fromLocal8Bit(" loaded . . . .");
}
