#include "QRPAMotorController.h"

QRPAMotorController::QRPAMotorController(QObject *parent) : QObject(parent)
{

}
