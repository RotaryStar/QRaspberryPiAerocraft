#include "QRPAMotorController.h"

QRPAMotorController::QRPAMotorController(QObject *parent) : QObject(parent)
{
	wiringPiSetup();
	pinMode(4, OUTPUT);
	pinMode(5, OUTPUT);
	pinMode(26, OUTPUT);
	pinMode(27, OUTPUT);

	digitalWrite(4, 0);
	digitalWrite(5, 0);
	digitalWrite(26, 0);
	digitalWrite(27, 0);
	pwmSetClock(2);

	softPwmCreate(4, 0, 200);
	softPwmCreate(5, 0, 200);
	softPwmCreate(26, 0, 200);
	softPwmCreate(27, 0, 200);

	maxPower = 20;
	minPower = 10;
}

void QRPAMotorController::setPwmCreate(int value)
{
	softPwmWrite(4, value);
    softPwmWrite(5, value);
    softPwmWrite(26, value);
    softPwmWrite(27, value);
}
