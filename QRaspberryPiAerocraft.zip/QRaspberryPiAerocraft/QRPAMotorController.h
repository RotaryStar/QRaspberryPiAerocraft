#ifndef QRPAMOTORCONTROLLER_H
#define QRPAMOTORCONTROLLER_H

#include <QObject>

#include "QRPAMotorControllerAlgoritms.h"

#include <wiringPi.h>
#include "softPwm.h"

class QRPAMotorController : public QObject
{
	friend class QRPAInstructionReceiving;

    Q_OBJECT
public:
    explicit QRPAMotorController(QObject *parent = 0);

private :
	void setPwmCreate(int value);

signals:

public slots:


private:
	int maxPower;
	int minPower;
};

#endif // QRPAMOTORCONTROLLER_H
