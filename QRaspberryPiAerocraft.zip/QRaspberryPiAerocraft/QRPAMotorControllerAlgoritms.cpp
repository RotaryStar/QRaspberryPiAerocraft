#include "QRPAMotorControllerAlgoritms.h"

QRPAMotorControllerAlgoritms::QRPAMotorControllerAlgoritms(QObject *parent) : QObject(parent)
{

}
