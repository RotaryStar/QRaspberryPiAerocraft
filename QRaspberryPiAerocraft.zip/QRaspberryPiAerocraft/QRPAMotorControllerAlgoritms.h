#ifndef QRPAMOTORCONTROLLERALGORITMS_H
#define QRPAMOTORCONTROLLERALGORITMS_H

#include <QObject>

class QRPAMotorControllerAlgoritms : public QObject
{
    Q_OBJECT
public:
    explicit QRPAMotorControllerAlgoritms(QObject *parent = 0);

signals:

public slots:
};

#endif // QRPAMOTORCONTROLLERALGORITMS_H