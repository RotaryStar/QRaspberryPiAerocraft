#include "QRPANetworkDataPakage.h"

QRPANetworkDataPakageR::QRPANetworkDataPakageR()
{

}






QRPANetworkDataPakageC::QRPANetworkDataPakageC()
{

}
