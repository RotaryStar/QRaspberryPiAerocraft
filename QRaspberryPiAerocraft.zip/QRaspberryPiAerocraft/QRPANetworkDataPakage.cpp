#include "QRPANetworkDataPakage.h"

QRPANetworkDataPakage::QRPANetworkDataPakage()
{

}
