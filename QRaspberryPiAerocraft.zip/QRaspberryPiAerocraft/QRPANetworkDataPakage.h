#ifndef QRPANETWORKDATAPAKAGE_H
#define QRPANETWORKDATAPAKAGE_H

#include <qstring.h>
#include <stdio.h>

class QRPANetworkDataPakage
{
public:
    QRPANetworkDataPakage();

    QString
};

#endif // QRPANETWORKDATAPAKAGE_H
