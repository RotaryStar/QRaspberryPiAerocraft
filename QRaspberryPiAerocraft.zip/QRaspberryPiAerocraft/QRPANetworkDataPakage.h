#ifndef QRPANETWORKDATAPAKAGE_H
#define QRPANETWORKDATAPAKAGE_H

#include <qstring.h>
#include <stdio.h>

class QRPANetworkDataPakageControlDirection
{
public:
	QRPANetworkDataPakageControlDirection(int layoutWidth = 200, int layoutHigh = 200, int originX = 0, int originY = 0)
	{
		width = layoutWidth;
		high = layoutHigh;
		ox = originX;
		oy = originY;
	}

	QRPANetworkDataPakageControlDirection(QRPANetworkDataPakageControlDirection &item)
	{
		this->x = item.x;
		this->y = item.y;
		this->width = item.width;
		this->high = item.high;
		this->ox = item.ox;
		this->oy = item.oy;
	}
	bool setInitialization(int layoutWidth = 200, int layoutHigh = 200, int originX = 0, int originY = 0)
	{
		width = layoutWidth;
		high = layoutHigh;
		ox = originX;
		oy = originY;

        return true;
	}
	bool setX(int value)
	{
		if (value > (-(ox/2))  && value > (ox / 2) )
		{
			x = value;
			return true;
		}
		return false;
	}
	bool setY(int value)
	{
		if (value > (-(oy / 2)) && value > (oy / 2))
		{
			y = value;
			return true;
		}
		return false;
	}

	int x, y;
	int width, high;
	int ox, oy;
};

class QRPANetworkDataPakageR
{
public:
    QRPANetworkDataPakageR();

	unsigned motorSpeedA;
	unsigned motorSpeedB;
	unsigned motorSpeedC;
	unsigned motorSpeedD;

	unsigned Power;
};

class QRPANetworkDataPakageC
{
public:
	QRPANetworkDataPakageC();

	int targetThrottle;     //For example , 90 percent
	QRPANetworkDataPakageControlDirection cd;
};

#endif // QRPANETWORKDATAPAKAGE_H
