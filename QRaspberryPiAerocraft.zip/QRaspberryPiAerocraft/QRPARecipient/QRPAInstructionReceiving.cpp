#include "QRPAInstructionReceiving.h"

QRPAInstructionReceiving::QRPAInstructionReceiving(QRPAMotorController *QRPAC, QObject *parent) : QObject(parent)
{
	socket = NULL;
	mQRPAC = QRPAC;

	if (server.listen(QHostAddress::Any, 25678))
	{
		qDebug() << "listen successful , port : 25678";
		connect(&server, &QTcpServer::newConnection, this, &QRPAInstructionReceiving::hasNewConnection);
	}
}

void QRPAInstructionReceiving::hasNewConnection()
{
	if (socket)
	{
		socket = server.nextPendingConnection();

		connect(socket, &QTcpSocket::readyRead, this, &QRPAInstructionReceiving::readyReadFromController);
	}
	else
	{
		qDebug() << "has new Connection , rejected ! because: has a connection connected ";
	}
}

void QRPAInstructionReceiving::readyReadFromController()
{
	QByteArray data = socket->readAll();

	int power = data.toInt();

	if (power > mQRPAC->maxPower)
	{
		power = mQRPAC->maxPower -((mQRPAC->maxPower - mQRPAC->minPower)/2);
	}
	else if (power < mQRPAC->minPower)
	{
		power = mQRPAC->minPower + ((mQRPAC->maxPower - mQRPAC->minPower) / 2);
	}

	mQRPAC->setPwmCreate(data.toInt());
}
